		<div id="banner">
			<div id="banner_pict">
                <a href="index.php"><img class ="full" src="./banner.png" alt="ProFILE Logo" /></a>

			</div>
			<div id="banner_foot">
			</div>
		</div>
		<?php echo "<h1>$header</h1>"?>
		
