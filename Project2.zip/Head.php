<?php
#session_id('mySessionID');
session_start();

echo '<?xml version="1.0" encoding="utf-8"?>' ?>
<?php  echo "\n"?>
<?php  echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';
?>


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <?php echo "<title> $title </title>\n" ?>
    <link href="style.css" rel="stylesheet" type="text/css" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="content-style-type" content="text/css" />
    <meta name="author" content="Pedro Quinones and Nathan Pitts" />
    <meta name="description" content="CT-310 Project 2: Social Networking Site" />
    <meta name="keywords" content="HTML,CSS,PHP,CT310,Social,Networking" />
</head>
<!-- Start of page Body -->
<body>